<?php

use App\Http\Middleware\EnsurePermission;
use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware) {
        $middleware->alias([
            'permission' => EnsurePermission::class,
        ]);
        $middleware->redirectGuestsTo(function ($request) {
            return $request->is('customer/*') ? route('customer.login') : route('admin.login');
        });
    })
    ->withExceptions(function (Exceptions $exceptions) {
        // Exception rendering remains Laravel's default.
    })->create();
