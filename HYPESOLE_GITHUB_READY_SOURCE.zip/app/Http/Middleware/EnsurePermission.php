<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsurePermission
{
    public function handle(Request $request, Closure $next, string $permission): Response
    {
        $user = $request->user('web');

        abort_unless($user && $user->hasPermission($permission), 403, 'Kamu tidak memiliki izin untuk membuka halaman ini.');

        return $next($request);
    }
}
